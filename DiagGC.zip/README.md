# DiagGC – Détection IA des pathologies

Projet minimal prêt pour **Vercel**. Front statique + fonction **serverless** `/api/predict`.

## Déploiement rapide
1. Ajouter la variable d’environnement sur Vercel : `HF_TOKEN=hf_...`
   - Optionnel : `ROBOFLOW_API_KEY`, `ROBOFLOW_MODEL`, `ROBOFLOW_VERSION`, `RF_WEIGHT`.
2. Importer ce dossier dans Vercel (Upload Project ou GitHub).
3. Vercel installe `busboy` et déploie l’API.
4. Ouvrir l’URL, choisir une image → **Diagnostiquer**.

## Structure
- `index.html` : interface mobile simple (nom de l’ouvrage, auteur, upload photo, JSON de config IA).
- `api/predict.js` : lit l’image, appelle Hugging Face et (si renseigné) Roboflow, fusionne les scores.
- `vercel.json` : configuration des fonctions.
- `package.json` : dépendance `busboy`.

## Remarques
- Les clés ne sont **jamais** côté navigateur.
- Pour exporter un rapport PDF, utilisez le bouton **Exporter PDF** (impression navigateur).
